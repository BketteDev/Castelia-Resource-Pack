#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = Color;
#endif
    texCoord0 = UV0;

#ifdef IS_GUI
    // Reserved Castelia colours. Normal GUI/world text follows the vanilla path.
    ivec3 marker = ivec3(round(Color.rgb * 255.0));
    if ((marker.g == 253 || marker.g == 252) && marker.b == 251 &&
        (marker.r == 30 || (marker.r >= 40 && marker.r <= 58))) {
        float row = marker.r == 30 ? 0.0 : float(marker.r - 40);
        vec2 guiSize = round(vec2(2.0 / ProjMat[0][0], -2.0 / ProjMat[1][1]));
        vec4 gui = ModelViewMat * vec4(Position, 1.0);
        vec2 local = gui.xy - vec2(floor(guiSize.x / 2.0) - 78.0, guiSize.y - 72.0);
        local.y += 2.0 * row * 10.0 + (marker.r == 30 ? 0.0 : 8.0);
        float scale = min(1.0, min((guiSize.y - 16.0) / 206.0, (guiSize.x - 24.0) / 164.0));
        vec2 origin = vec2(12.0, max(8.0, (guiSize.y - 206.0 * scale) / 2.0));
        gui.xy = origin + local * scale;
        gl_Position = ProjMat * gui;
        vec3 tint = marker.g == 252 ? vec3(0.60, 0.96, 0.91) : vec3(0.47, 0.59, 0.67);
        if (marker.r == 30) tint = vec3(1.0);
        else if (row == 0.0) tint = vec3(0.30, 0.91, 0.95);
        else if (row == 16.0) tint = vec3(0.80, 0.65, 1.0);
        else if (row == 18.0) tint = vec3(0.55, 0.67, 0.72);
        vertexColor = vec4(tint, Color.a);
    }
#endif

}
